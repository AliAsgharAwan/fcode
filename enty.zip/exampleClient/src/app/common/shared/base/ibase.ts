export interface IBase {
  id: number;
}
